const estados= [

    // Tarfia 2
    {
        'nombre': 'Aguascalientes',
        'tarifa': 2
    },
    {
        'nombre': 'San Luis Potosí ',
        'tarifa': 2
    },
    {
        'nombre': 'Veracruz',
        'tarifa': 2
    },
    {
        'nombre': 'Hidalgo',
        'tarifa': 2
    },
    {
        'nombre': 'Michoacán',
        'tarifa': 2
    },
    {
        'nombre': 'Oaxaca',
        'tarifa': 2
    },
    {
        'nombre': 'Zacatecas',
        'tarifa': 2
    },
    {
        'nombre': 'Guadalajara',
        'tarifa': 2
    },
    {
        'nombre': 'Puebla',
        'tarifa': 2
    },
    {
        'nombre': 'Querétaro',
        'tarifa': 2
    },
    //  Tarifa 1
    {
        'nombre': 'Chihuahua',
        'tarifa': 1
    },
    {
        'nombre': 'Morelos',
        'tarifa': 1
    },
    {
        'nombre': 'Quintana Roo',
        'tarifa': 1
    },
    {
        'nombre': 'Sinaloa',
        'tarifa': 1
    },
    {
        'nombre': 'Sonora',
        'tarifa': 1
    },
    {
        'nombre': 'Tamaulipas',
        'tarifa': 1
    },
    {
        'nombre': 'Baja California Norte',
        'tarifa': 1
    },
    {
        'nombre': 'Baja California Sur ',
        'tarifa': 1
    },
    {
        'nombre': 'Tabasco',
        'tarifa': 1
    },
    {
        'nombre': 'CDMX',
        'tarifa': 1
    },
    {
        'nombre': 'Edo. Mex.',
        'tarifa': 1
    },
    {
        'nombre': 'Coahuila',
        'tarifa': 1
    },
    {
        'nombre': 'Nuevo León',
        'tarifa': 1
    },
    {
        'nombre': 'Yucatán',
        'tarifa': 1
    },
    // Tarifa 3
    {
        'nombre': 'Guanajuato',
        'tarifa': 1
    },

    ]
    export {estados};