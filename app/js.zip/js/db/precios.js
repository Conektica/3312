const objeto= [
    {
    'id': 0,
    'edad': 0,
    'tarifa':{
        '1': {
            'Masculino': 1303.79, 
            'Femenino': 790.38 
        },
        '2':{
            'Masculino': 1108.22, 
            'Femenino': 671.82 
        },
        '3':{
            'Masculino': 839.77, 
            'Femenino': 644.84 
        }
    }
},

{
    'id': 1,
    'edad': 1,
    'tarifa':{
        '1': {
            'Masculino':  1001.37, 
            'Femenino':  559.24 
        },
        '2':{
            'Masculino':  851.16, 
            'Femenino':  475.35  
        },
        '3':{
            'Masculino':  644.98, 
            'Femenino':  456.26 
        }
    }
},

{
    'id': 2,
    'edad': 2,
    'tarifa':{
        '1': {
            'Masculino':  802.79, 
            'Femenino':  423.7828 
        },
        '2':{
            'Masculino':  682.37116, 
            'Femenino':  360.21538  
        },
        '3':{
            'Masculino': 517.08287751281, 
            'Femenino':  345.754052760722
        }
    }
},

{
    'id': 3,
    'edad': 3,
    'tarifa':{
        '1': {
            'Masculino': 668.74, 
            'Femenino':  341.446 
        },
        '2':{
            'Masculino':  568.429, 
            'Femenino': 290.2291  
        },
        '3':{
            'Masculino': 430.732474340753, 
            'Femenino':  278.573053881881
        }
    }
},

{
    'id': 4,
    'edad': 4,
    'tarifa':{
        '1': {
            'Masculino':  576.3344, 
            'Femenino':  290.4756
        },
        '2':{
            'Masculino':  489.88424, 
            'Femenino': 246.90426  
        },
        '3':{
            'Masculino':  371.217386222037, 
            'Femenino': 236.994487586724
        }
    }
},

{
    'id': 5,
    'edad': 5,
    'tarifa':{
        '1': {
            'Masculino': 511.8384, 
            'Femenino': 259.26
        },
        '2':{
            'Masculino':  435.06264, 
            'Femenino':  220.371 
        },
        '3':{
            'Masculino': 329.675782725, 
            'Femenino': 211.52690536359
        }
    }
},

{
    'id': 6,
    'edad': 6,
    'tarifa':{
        '1': {
            'Masculino':  466.6796, 
            'Femenino':  241.3148
        },
        '2':{
            'Masculino': 396.67766, 
            'Femenino':  205.11758 
        },
        '3':{
            'Masculino':  300.587778932857, 
            'Femenino':  196.881820822952
        }
    }
},

{
    'id': 7,
    'edad': 7,
    'tarifa':{
        '1': {
            'Masculino': 435.3364, 
            'Femenino':  232.9164 
        },
        '2':{
            'Masculino':  370.03594, 
            'Femenino':  197.97894
        },
        '3':{
            'Masculino': 280.406019389835, 
            'Femenino': 190.029376115315
        }
    }
},

{
    'id': 8,
    'edad': 8,
    'tarifa':{
        '1': {
            'Masculino': 414.1896, 
            'Femenino': 231.9188
        },
        '2':{
            'Masculino': 352.06116, 
            'Femenino':  197.13098
        },
        '3':{
            'Masculino': 266.781698312543, 
            'Femenino':  189.210918809285
        }
    }
},

{
    'id': 9,
    'edad': 9,
    'tarifa':{
        '1': {
            'Masculino':  400.7336, 
            'Femenino':  237.0576
        },
        '2':{
            'Masculino':  340.62356, 
            'Femenino':  201.49896  
        },
        '3':{
            'Masculino':  258.112565228572, 
            'Femenino':  193.412483084945
        }
    }
},

{
    'id': 10,
    'edad': 10,
    'tarifa':{
        '1': {
            'Masculino':  393.2052, 
            'Femenino': 247.6832 
        },
        '2':{
            'Masculino': 334.22442, 
            'Femenino':  210.53072  
        },
        '3':{
            'Masculino':  253.270851294612, 
            'Femenino':  202.069201721708 
        }
    }
},

{
    'id': 11,
    'edad': 11,
    'tarifa':{
        '1': {
            'Masculino':  390.3632, 
            'Femenino': 263.3896
        },
        '2':{
            'Masculino':  331.80872, 
            'Femenino': 223.88116  
        },
        '3':{
            'Masculino': 251.434923677079, 
            'Femenino': 214.888952528315 
        }
    }
},

{
    'id': 12,
    'edad': 12,
    'tarifa':{
        '1': {
            'Masculino':  391.21, 
            'Femenino':  284.0376
        },
        '2':{
            'Masculino':  332.5285, 
            'Femenino':  241.43196 
        },
        '3':{
            'Masculino':  251.982609458249, 
            'Femenino':  231.738705294516
        }
    }
},

{
    'id': 13,
    'edad': 13,
    'tarifa':{
        '1': {
            'Masculino':  395.0032, 
            'Femenino':  309.5692
        },
        '2':{
            'Masculino': 335.75272, 
            'Femenino': 263.13382 
        },
        '3':{
            'Masculino': 254.422360234273, 
            'Femenino':  252.564063478658
        }
    }
},

{
    'id': 14,
    'edad': 14,
    'tarifa':{
        '1': {
            'Masculino': 401.1048, 
            'Femenino': 339.9264
        },
        '2':{
            'Masculino':  340.93908, 
            'Femenino':  288.93744 
        },
        '3':{
            'Masculino': 258.348428306018, 
            'Femenino': 277.326514955395 
        }
    }
},

{
    'id': 15,
    'edad': 15,
    'tarifa':{
        '1': {
            'Masculino':  408.958, 
            'Femenino': 375.0048
        },
        '2':{
            'Masculino':  347.6143, 
            'Femenino':  318.75408 
        },
        '3':{
            'Masculino': 263.411833064286, 
            'Femenino': 305.950710599554 
        }
    }
},

{
    'id': 16,
    'edad': 16,
    'tarifa':{
        '1': {
            'Masculino': 418.0988, 
            'Femenino':  414.6304 
        },
        '2':{
            'Masculino': 355.38398, 
            'Femenino':  352.43584 
        },
        '3':{
            'Masculino': 269.302089912229, 
            'Femenino': 338.278795026183 
        }
    }
},

{
    'id': 17,
    'edad': 17,
    'tarifa':{
        '1': {
            'Masculino': 428.098, 
            'Femenino': 458.4552 
        },
        '2':{
            'Masculino':  363.8833, 
            'Femenino':  389.68692  
        },
        '3':{
            'Masculino': 275.736505150403, 
            'Femenino':  374.031830654698
        }
    }
},

{
    'id': 18,
    'edad': 18,
    'tarifa':{
        '1': {
            'Masculino':  438.5148, 
            'Femenino': 505.9456
        },
        '2':{
            'Masculino':  372.73758, 
            'Femenino':  430.05376 
        },
        '3':{
            'Masculino': 282.454886610831, 
            'Femenino':  412.780266957145 
        }
    }
},

{
    'id': 19,
    'edad': 19,
    'tarifa':{
        '1': {
            'Masculino':  449.0244, 
            'Femenino':  556.3824 
        },
        '2':{
            'Masculino': 381.67074, 
            'Femenino':  472.92504 
        },
        '3':{
            'Masculino': 289.218111802365, 
            'Femenino':  453.926394127829 
        }
    }
},

{
    'id': 20,
    'edad': 20,
    'tarifa':{
        '1': {
            'Masculino': 459.2556, 
            'Femenino':  608.8028 
        },
        '2':{
            'Masculino':  390.36726, 
            'Femenino':  517.48238
        },
        '3':{
            'Masculino':  295.809330001365, 
            'Femenino': 496.701806332286 
        }
    }
},

{
    'id': 21,
    'edad': 21,
    'tarifa':{
        '1': {
            'Masculino':  468.93, 
            'Femenino':  662.1048
        },
        '2':{
            'Masculino':  398.5905, 
            'Femenino': 562.78908  
        },
        '3':{
            'Masculino':  302.036774213034, 
            'Femenino':  540.182097669793 
        }
    }
},

{
    'id': 22,
    'edad': 22,
    'tarifa':{
        '1': {
            'Masculino':  477.7692, 
            'Femenino': 714.9776
        },
        '2':{
            'Masculino':  406.10382, 
            'Femenino':  607.73096  
        },
        '3':{
            'Masculino':  307.737300039714, 
            'Femenino':  583.319428492154 
        }
    }
},

{
    'id': 23,
    'edad': 23,
    'tarifa':{
        '1': {
            'Masculino': 485.6108, 
            'Femenino':  766.0524 
        },
        '2':{
            'Masculino':  412.76918, 
            'Femenino': 651.14454  
        },
        '3':{
            'Masculino':  312.779897789146, 
            'Femenino':  624.991474921785 
        }
    }
},

{
    'id': 24,
    'edad': 24,
    'tarifa':{
        '1': {
            'Masculino':  492.2692, 
            'Femenino': 813.9488 
        },
        '2':{
            'Masculino': 418.42882, 
            'Femenino':  691.85648  
        },
        '3':{
            'Masculino': 317.06856609072, 
            'Femenino':  664.06298767563 
        }
    }
},

{
    'id': 25,
    'edad': 25,
    'tarifa':{
        '1': {
            'Masculino':  497.6632, 
            'Femenino': 857.3212
        },
        '2':{
            'Masculino':  423.01372, 
            'Femenino':  728.72302  
        },
        '3':{
            'Masculino':  320.544097456244, 
            'Femenino':  699.454188822001 
        }
    }
},

{
    'id': 26,
    'edad': 26,
    'tarifa':{
        '1': {
            'Masculino': 501.758, 
            'Femenino':  895.0096 
        },
        '2':{
            'Masculino':  426.4943, 
            'Femenino':  760.75816 
        },
        '3':{
            'Masculino': 323.184503835279, 
            'Femenino':  730.20895559088 
        }
    }
},

{
    'id': 27,
    'edad': 27,
    'tarifa':{
        '1': {
            'Masculino':  504.5884, 
            'Femenino':  926.086 
        },
        '2':{
            'Masculino': 428.90014, 
            'Femenino': 787.1731
        },
        '3':{
            'Masculino': 325.003990596419, 
            'Femenino':  755.555480554163
        }
    }
},

{
    'id': 28,
    'edad': 28,
    'tarifa':{
        '1': {
            'Masculino':  506.2008, 
            'Femenino':  949.8544
        },
        '2':{
            'Masculino':  430.27068, 
            'Femenino': 807.37624  
        },
        '3':{
            'Masculino':  326.050554467493, 
            'Femenino':  774.952952769698 
        }
    }
},

{
    'id': 29,
    'edad': 29,
    'tarifa':{
        '1': {
            'Masculino': 506.746, 
            'Femenino':  965.99 
        },
        '2':{
            'Masculino': 430.7341, 
            'Femenino': 821.0915  
        },
        '3':{
            'Masculino': 326.402419489968, 
            'Femenino':  788.119636156663
        }
    }
},

{
    'id': 30,
    'edad': 30,
    'tarifa':{
        '1': {
            'Masculino':  506.3864, 
            'Femenino': 974.4696 
        },
        '2':{
            'Masculino':  430.42844, 
            'Femenino':  828.29916 
        },
        '3':{
            'Masculino':  326.163623624159, 
            'Femenino':  795.040190496553  
        }
    }
},

{
    'id': 31,
    'edad': 31,
    'tarifa':{
        '1': {
            'Masculino': 505.296, 
            'Femenino': 975.5948 
        },
        '2':{
            'Masculino':  429.5016, 
            'Femenino':  829.25558
        },
        '3':{
            'Masculino':  325.459121727808, 
            'Femenino':  795.952732766896
        }
    }
},

{
    'id': 32,
    'edad': 32,
    'tarifa':{
        '1': {
            'Masculino': 503.6952, 
            'Femenino': 969.9108 
        },
        '2':{
            'Masculino':  428.14092, 
            'Femenino':  824.42418 
        },
        '3':{
            'Masculino':  324.429778903396, 
            'Femenino': 791.318512041592
        }
    }
},

{
    'id': 33,
    'edad': 33,
    'tarifa':{
        '1': {
            'Masculino': 501.8276, 
            'Femenino': 958.218 
        },
        '2':{
            'Masculino': 426.55346, 
            'Femenino':  814.4853 
        },
        '3':{
            'Masculino':  323.227597750585, 
            'Femenino':  781.778806104863
        }
    }
},

{
    'id': 34,
    'edad': 34,
    'tarifa':{
        '1': {
            'Masculino': 499.9368, 
            'Femenino': 941.4676 
        },
        '2':{
            'Masculino':  424.94628, 
            'Femenino':  800.24746
        },
        '3':{
            'Masculino':  322.011463645336, 
            'Femenino':  768.104541644928
        }
    }
},

{
    'id': 35,
    'edad': 35,
    'tarifa':{
        '1': {
            'Masculino':  498.278, 
            'Femenino': 920.6688 
        },
        '2':{
            'Masculino':  423.5363, 
            'Femenino':  782.56848
        },
        '3':{
            'Masculino':  320.943615187136, 
            'Femenino':  751.144174157475
        }
    }
},

{
    'id': 36,
    'edad': 36,
    'tarifa':{
        '1': {
            'Masculino':  497.1064, 
            'Femenino': 896.9352
        },
        '2':{
            'Masculino': 422.54044, 
            'Femenino':  762.39492 
        },
        '3':{
            'Masculino':  320.186963430707, 
            'Femenino': 731.774676259323
        }
    }
},

{
    'id': 37,
    'edad': 37,
    'tarifa':{
        '1': {
            'Masculino':  496.6656, 
            'Femenino': 871.2992
        },
        '2':{
            'Masculino': 422.16576, 
            'Femenino':  740.60432
        },
        '3':{
            'Masculino': 319.903302543677, 
            'Femenino':  710.859311100358
        }
    }
},

{
    'id': 38,
    'edad': 38,
    'tarifa':{
        '1': {
            'Masculino':  497.1992, 
            'Femenino': 844.77
        },
        '2':{
            'Masculino': 422.61932, 
            'Femenino':  718.0545
        },
        '3':{
            'Masculino': 320.252382326467, 
            'Femenino':  689.214480668197
        }
    }
},

{
    'id': 39,
    'edad': 39,
    'tarifa':{
        '1': {
            'Masculino': 498.974, 
            'Femenino': 818.2524 
        },
        '2':{
            'Masculino':  424.1279, 
            'Femenino': 695.51454 
        },
        '3':{
            'Masculino':  321.391752597596, 
            'Femenino': 667.586580821598
        }
    }
},

{
    'id': 40,
    'edad': 40,
    'tarifa':{
        '1': {
            'Masculino': 502.2104, 
            'Femenino': 792.5816
        },
        '2':{
            'Masculino':  426.87884, 
            'Femenino':  673.69436
        },
        '3':{
            'Masculino':  323.477240732178, 
            'Femenino':  646.638645230214
        }
    }
},

{
    'id': 41,
    'edad': 41,
    'tarifa':{
        '1': {
            'Masculino':  507.1636, 
            'Femenino': 768.442
        },
        '2':{
            'Masculino':  431.08906, 
            'Femenino':  653.1757
        },
        '3':{
            'Masculino':  326.663884020868, 
            'Femenino': 626.945718705567
        }
    }
},

{
    'id': 42,
    'edad': 42,
    'tarifa':{
        '1': {
            'Masculino':  514.054, 
            'Femenino': 746.4368
        },
        '2':{
            'Masculino':  436.9459, 
            'Femenino':  634.47128
        },
        '3':{
            'Masculino':  331.107103448067, 
            'Femenino':  608.997391367688
        }
    }
},

{
    'id': 43,
    'edad': 43,
    'tarifa':{
        '1': {
            'Masculino':  523.1484, 
            'Femenino':727.088 
        },
        '2':{
            'Masculino':  444.67614, 
            'Femenino':  618.0248 
        },
        '3':{
            'Masculino':  336.96386918576, 
            'Femenino':  593.20571595143
        }
    }
},

{
    'id': 44,
    'edad': 44,
    'tarifa':{
        '1': {
            'Masculino':  534.6788, 
            'Femenino': 710.8016
        },
        '2':{
            'Masculino':  454.47698, 
            'Femenino':  604.18136
        },
        '3':{
            'Masculino':  344.39356418002, 
            'Femenino':  579.91675363765
        }
    }
},

{
    'id': 45,
    'edad': 45,
    'tarifa':{
        '1': {
            'Masculino':  548.912, 
            'Femenino': 697.9372 
        },
        '2':{
            'Masculino':  466.5752, 
            'Femenino':  593.24662 
        },
        '3':{
            'Masculino':  353.558194331405, 
            'Femenino': 569.424167645953
        }
    }
},

{
    'id': 46,
    'edad': 46,
    'tarifa':{
        '1': {
            'Masculino':  566.0916, 
            'Femenino': 688.808 
        },
        '2':{
            'Masculino':  481.17786, 
            'Femenino': 585.4868
        },
        '3':{
            'Masculino':  364.621516384984, 
            'Femenino':  561.983529216686
        }
    }
},

{
    'id': 47,
    'edad': 47,
    'tarifa':{
        '1': {
            'Masculino':  586.4612, 
            'Femenino': 683.7272 
        },
        '2':{
            'Masculino': 498.49202, 
            'Femenino':  581.16812 
        },
        '3':{
            'Masculino':  377.746554028254, 
            'Femenino': 557.826250078646
        }
    }
},

{
    'id': 48,
    'edad': 48,
    'tarifa':{
        '1': {
            'Masculino': 610.2876, 
            'Femenino': 682.9152 
        },
        '2':{
            'Masculino':  518.74446, 
            'Femenino':  580.47792
        },
        '3':{
            'Masculino':  393.090848577953, 
            'Femenino': 557.172257040593
        }
    }
},

{
    'id': 49,
    'edad': 49,
    'tarifa':{
        '1': {
            'Masculino':  637.7912, 
            'Femenino': 686.6852 
        },
        '2':{
            'Masculino': 542.12252, 
            'Femenino':  583.68242 
        },
        '3':{
            'Masculino':  410.798648753877, 
            'Femenino':  560.240640888222
        }
    }
},

{
    'id': 50,
    'edad': 50,
    'tarifa':{
        '1': {
            'Masculino': 669.1228, 
            'Femenino': 695.2808 
        },
        '2':{
            'Masculino': 568.75438, 
            'Femenino':  590.98868
        },
        '3':{
            'Masculino':  430.989099958022, 
            'Femenino':  567.2575184625
        }
    }
},

{
    'id': 51,
    'edad': 51,
    'tarifa':{
        '1': {
            'Masculino':  704.4564, 
            'Femenino': 709.0152
        },
        '2':{
            'Masculino': 598.78794, 
            'Femenino':  602.66292 
        },
        '3':{
            'Masculino':  453.73937799001, 
            'Femenino': 578.460228094872
        }
    }
},

{
    'id': 52,
    'edad': 52,
    'tarifa':{
        '1': {
            'Masculino': 743.7688, 
            'Femenino':728.1784 
        },
        '2':{
            'Masculino': 632.20348, 
            'Femenino':  618.95164
        },
        '3':{
            'Masculino': 479.061678130149, 
            'Femenino':  594.096726959683
        }
    }
},

{
    'id': 53,
    'edad': 53,
    'tarifa':{
        '1': {
            'Masculino':  786.944, 
            'Femenino': 753.0952 
        },
        '2':{
            'Masculino':  668.9024, 
            'Femenino':  640.13092
        },
        '3':{
            'Masculino':  506.873100616211, 
            'Femenino':  614.418676993081
        }
    }
},

{
    'id': 54,
    'edad': 54,
    'tarifa':{
        '1': {
            'Masculino': 833.6572, 
            'Femenino': 784.0324 
        },
        '2':{
            'Masculino': 708.60862, 
            'Femenino':  666.42754
        },
        '3':{
            'Masculino': 536.957886226777, 
            'Femenino':  639.666213925041
        }
    }
},

{
    'id': 55,
    'edad': 55,
    'tarifa':{
        '1': {
            'Masculino': 883.2704, 
            'Femenino': 821.2684 
        },
        '2':{
            'Masculino':  750.77984, 
            'Femenino':  698.07814 
        },
        '3':{
            'Masculino':  568.922305745636, 
            'Femenino':  670.041843802112
        }
    }
},

{
    'id': 56,
    'edad': 56,
    'tarifa':{
        '1': {
            'Masculino':  934.8556, 
            'Femenino': 864.9424
        },
        '2':{
            'Masculino':  794.62726, 
            'Femenino':  735.20104
        },
        '3':{
            'Masculino':  602.143972730929, 
            'Femenino':  705.670410748602
        }
    }
},

{
    'id': 57,
    'edad': 57,
    'tarifa':{
        '1': {
            'Masculino':  986.986, 
            'Femenino': 915.0312 
        },
        '2':{
            'Masculino': 838.9381, 
            'Femenino':  777.77652
        },
        '3':{
            'Masculino':  635.719594862217, 
            'Femenino':  746.541824506291
        }
    }
},

{
    'id': 58,
    'edad': 58,
    'tarifa':{
        '1': {
            'Masculino': 1037.7476, 
            'Femenino': 971.2796 
        },
        '2':{
            'Masculino':  882.08546, 
            'Femenino':  825.58766
        },
        '3':{
            'Masculino':  668.418281859771, 
            'Femenino':  792.433549521261
        }
    }
},

{
    'id': 59,
    'edad': 59,
    'tarifa':{
        '1': {
            'Masculino': 1084.6928, 
            'Femenino': 1033.038
        },
        '2':{
            'Masculino':  921.98888, 
            'Femenino':  878.0823 
        },
        '3':{
            'Masculino':  698.651353955969, 
            'Femenino': 842.811222940567
        }
    }
},

{
    'id': 60,
    'edad': 60,
    'tarifa':{
        '1': {
            'Masculino':  1124.7824, 
            'Femenino':1099.0884    
        },
        '2':{
            'Masculino':  956.06504, 
            'Femenino':  934.22514
        },
        '3':{
            'Masculino':  724.473631883208, 
            'Femenino': 896.70883546481
        }
    }
},

{
    'id': 61,
    'edad': 61,
    'tarifa':{
        '1': {
            'Masculino':  1154.5248, 
            'Femenino': 1167.5864 
        },
        '2':{
            'Masculino': 981.34608, 
            'Femenino': 992.44844
        },
        '3':{
            'Masculino': 743.634363482573, 
            'Femenino':  952.595418578283
        }
    }
},

{
    'id': 62,
    'edad': 62,
    'tarifa':{
        '1': {
            'Masculino': 1170.15, 
            'Femenino':1235.7944 
        },
        '2':{
            'Masculino':  994.6275, 
            'Femenino': 1050.42524
        },
        '3':{
            'Masculino':  753.696502495868, 
            'Femenino':  1008.24375592941
        }
    }
},

{
    'id': 63,
    'edad': 63,
    'tarifa':{
        '1': {
            'Masculino':  1190.2528, 
            'Femenino': 1300.012
        },
        '2':{
            'Masculino':  1011.71488, 
            'Femenino': 1105.0102 
        },
        '3':{
            'Masculino':  766.641060535263, 
            'Femenino':  1060.62834353385
        }
    }
},

{
    'id': 64,
    'edad': 64,
    'tarifa':{
        '1': {
            'Masculino':  1215.3552, 
            'Femenino': 1355.4948 
        },
        '2':{
            'Masculino': 1033.05192, 
            'Femenino': 1152.17058
        },
        '3':{
            'Masculino':  782.814922571871, 
            'Femenino': 1105.89347916503
        }
    }
},

{
    'id': 65,
    'edad': 65,
    'tarifa':{
        '1': {
            'Masculino': 1255.526, 
            'Femenino':1396.6052 
        },
        '2':{
            'Masculino': 1067.1971, 
            'Femenino':  1187.11442
        },
        '3':{
            'Masculino': 808.693101830446, 
            'Femenino':  1139.44464335502
        }
    }
},
]

export {objeto};